DELIMITER //

CREATE PROCEDURE GetEmployeesByDepartment(
    IN p_department_id INT
)
BEGIN
SELECT employee_id,
       employee_name,
       email,
       salary,
       department_id
FROM employee
WHERE department_id = p_department_id;
END //

CREATE PROCEDURE IncreaseDepartmentSalary(
    IN p_department_id INT,
    IN p_percentage DECIMAL(5,2)
)
BEGIN
UPDATE employee
SET salary = salary + (salary * p_percentage / 100)
WHERE department_id = p_department_id;
END //

DELIMITER ;