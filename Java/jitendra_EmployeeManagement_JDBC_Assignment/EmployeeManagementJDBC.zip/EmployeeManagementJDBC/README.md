# Employee Management JDBC
Assumed existing schema: `employee_management`; `department(department_id, department_name)`; `employee(employee_id, employee_name, email, salary, department_id)`.
1. Update `src/main/resources/db.properties`.
2. Ensure the two stored procedures exist; adapt `sql/required_procedures.sql` to your existing names if needed.
3. IntelliJ: open `pom.xml` as Maven project and reload Maven.
4. Run `EmployeeManagementApplication`.
Do not commit the real database password. CRUD, prepared statements, join, aggregate, 2 callable statements, transaction rollback, batch processing, try-with-resources, input validation, and SQL error mapping are included.
