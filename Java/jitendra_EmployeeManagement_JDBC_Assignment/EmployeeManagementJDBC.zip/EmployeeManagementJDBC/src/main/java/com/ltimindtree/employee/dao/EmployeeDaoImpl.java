package com.ltimindtree.employee.dao;

import com.ltimindtree.employee.model.*;
import com.ltimindtree.employee.util.DBConnection;

import java.sql.*;
import java.util.*;

public class EmployeeDaoImpl implements EmployeeDao {
    private Employee map(ResultSet r) throws SQLException {
        return new Employee(r.getInt("employee_id"), r.getString("employee_name"), r.getString("email"), r.getDouble("salary"), r.getInt("department_id"));
    }

    public int add(Employee e) throws SQLException {
        String q = "INSERT INTO employee(employee_name,email,salary,department_id) VALUES(?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(q, Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1, e.getEmployeeName());
            p.setString(2, e.getEmail());
            p.setDouble(3, e.getSalary());
            p.setInt(4, e.getDepartmentId());
            p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) {
                if (r.next()) return r.getInt(1);
            }
            return 0;
        }
    }

    public List<Employee> findAll() throws SQLException {
        List<Employee> a = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement("SELECT employee_id,employee_name,email,salary,department_id FROM employee ORDER BY employee_id"); ResultSet r = p.executeQuery()) {
            while (r.next()) a.add(map(r));
        }
        return a;
    }

    public Optional<Employee> findById(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement("SELECT employee_id,employee_name,email,salary,department_id FROM employee WHERE employee_id=?")) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? Optional.of(map(r)) : Optional.empty();
            }
        }
    }

    public boolean update(Employee e) throws SQLException {
        String q = "UPDATE employee SET employee_name=?,email=?,salary=?,department_id=? WHERE employee_id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(q)) {
            p.setString(1, e.getEmployeeName());
            p.setString(2, e.getEmail());
            p.setDouble(3, e.getSalary());
            p.setInt(4, e.getDepartmentId());
            p.setInt(5, e.getEmployeeId());
            return p.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement("DELETE FROM employee WHERE employee_id=?")) {
            p.setInt(1, id);
            return p.executeUpdate() > 0;
        }
    }

    public List<Employee> findByDepartment(int d) throws SQLException {
        List<Employee> a = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement("SELECT employee_id,employee_name,email,salary,department_id FROM employee WHERE department_id=?")) {
            p.setInt(1, d);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) a.add(map(r));
            }
        }
        return a;
    }

    public List<EmployeeDepartmentView> findEmployeeDepartmentDetails() throws SQLException {
        List<EmployeeDepartmentView> a = new ArrayList<>();
        String q = "SELECT e.employee_id,e.employee_name,e.email,e.salary,d.department_name FROM employee e JOIN department d ON e.department_id=d.department_id ORDER BY e.employee_id";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(q); ResultSet r = p.executeQuery()) {
            while (r.next())
                a.add(new EmployeeDepartmentView(r.getInt(1), r.getString(2), r.getString(3), r.getDouble(4), r.getString(5)));
        }
        return a;
    }

    public Map<String, Integer> countByDepartment() throws SQLException {
        Map<String, Integer> m = new LinkedHashMap<>();
        String q = "SELECT d.department_name,COUNT(e.employee_id) employee_count FROM department d LEFT JOIN employee e ON d.department_id=e.department_id GROUP BY d.department_id,d.department_name ORDER BY d.department_name";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(q); ResultSet r = p.executeQuery()) {
            while (r.next()) m.put(r.getString(1), r.getInt(2));
        }
        return m;
    }

    public List<Employee> callEmployeesByDepartment(int d) throws SQLException {
        List<Employee> a = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); CallableStatement p = c.prepareCall("{CALL GetEmployeesByDepartment(?)}")) {
            p.setInt(1, d);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) a.add(map(r));
            }
        }
        return a;
    }

    public void callIncreaseSalary(int d, double pct) throws SQLException {
        try (Connection c = DBConnection.getConnection(); CallableStatement p = c.prepareCall("{CALL IncreaseDepartmentSalary(?,?)}")) {
            p.setInt(1, d);
            p.setDouble(2, pct);
            p.execute();
        }
    }

    public void transferEmployee(int emp, int dept) throws SQLException {
        String check = "SELECT department_id FROM department WHERE department_id=?", update = "UPDATE employee SET department_id=? WHERE employee_id=?";
        try (Connection c = DBConnection.getConnection()) {
            try {
                c.setAutoCommit(false);
                try (PreparedStatement p = c.prepareStatement(check)) {
                    p.setInt(1, dept);
                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) throw new SQLException("Department not found: " + dept);
                    }
                }
                try (PreparedStatement p = c.prepareStatement(update)) {
                    p.setInt(1, dept);
                    p.setInt(2, emp);
                    if (p.executeUpdate() == 0) throw new SQLException("Employee not found: " + emp);
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    public int[] batchInsert(List<Employee> es) throws SQLException {
        String q = "INSERT INTO employee(employee_name,email,salary,department_id) VALUES(?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(q)) {
            for (Employee e : es) {
                p.setString(1, e.getEmployeeName());
                p.setString(2, e.getEmail());
                p.setDouble(3, e.getSalary());
                p.setInt(4, e.getDepartmentId());
                p.addBatch();
            }
            return p.executeBatch();
        }
    }
}