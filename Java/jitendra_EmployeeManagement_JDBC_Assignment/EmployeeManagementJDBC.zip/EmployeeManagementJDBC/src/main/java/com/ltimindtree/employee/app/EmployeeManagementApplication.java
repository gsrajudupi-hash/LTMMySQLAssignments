package com.ltimindtree.employee.app;

import com.ltimindtree.employee.dao.EmployeeDaoImpl;
import com.ltimindtree.employee.model.Employee;
import com.ltimindtree.employee.service.EmployeeService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class EmployeeManagementApplication {

    private final Scanner scanner = new Scanner(System.in);

    private final EmployeeService employeeService =
            new EmployeeService(new EmployeeDaoImpl());

    public static void main(String[] args) {
        new EmployeeManagementApplication().start();
    }

    private void start() {

        while (true) {

            displayMenu();

            try {

                int choice = readInt("Enter your choice: ");

                switch (choice) {

                    case 1:
                        addEmployee();
                        break;

                    case 2:
                        viewAllEmployees();
                        break;

                    case 3:
                        findEmployee();
                        break;

                    case 4:
                        updateEmployee();
                        break;

                    case 5:
                        deleteEmployee();
                        break;

                    case 6:
                        employeeDetailsWithDepartment();
                        break;

                    case 7:
                        departmentWiseEmployeeCount();
                        break;

                    case 8:
                        executeStoredProcedure();
                        break;

                    case 9:
                        transferEmployee();
                        break;

                    case 10:
                        batchInsertEmployees();
                        break;

                    case 11:
                        System.out.println("Exiting Application...");
                        return;

                    default:
                        System.out.println("Invalid Choice!");
                }

            } catch (Exception exception) {
                System.out.println("Error : " + exception.getMessage());
            }
        }
    }

    private void displayMenu() {

        System.out.println();
        System.out.println("===========================================");
        System.out.println(" EMPLOYEE MANAGEMENT SYSTEM ");
        System.out.println("===========================================");
        System.out.println("1. Add Employee");
        System.out.println("2. View All Employees");
        System.out.println("3. Find Employee By ID");
        System.out.println("4. Update Employee");
        System.out.println("5. Delete Employee");
        System.out.println("6. Employee Details With Department");
        System.out.println("7. Department Wise Employee Count");
        System.out.println("8. Execute Stored Procedure");
        System.out.println("9. Transfer Employee");
        System.out.println("10. Batch Insert Employees");
        System.out.println("11. Exit");
        System.out.println("===========================================");
    }

    private void addEmployee() {

        System.out.println("\nADD EMPLOYEE");

        Employee employee = readEmployeeData(0);

        int generatedId = employeeService.add(employee);

        System.out.println("Employee Added Successfully.");
        System.out.println("Generated Employee ID : " + generatedId);
    }

    private void viewAllEmployees() {

        System.out.println("\nALL EMPLOYEES");

        List<Employee> employees = employeeService.all();

        if (employees.isEmpty()) {
            System.out.println("No employee found.");
            return;
        }

        employees.forEach(System.out::println);
    }

    private void findEmployee() {

        int employeeId = readInt("Enter Employee ID : ");

        Employee employee = employeeService.one(employeeId);

        System.out.println(employee);
    }

    private void updateEmployee() {

        int employeeId =
                readInt("Enter Employee ID To Update : ");

        Employee employee =
                readEmployeeData(employeeId);

        employeeService.update(employee);

        System.out.println("Employee Updated Successfully.");
    }

    private void deleteEmployee() {

        int employeeId =
                readInt("Enter Employee ID To Delete : ");

        employeeService.delete(employeeId);

        System.out.println("Employee Deleted Successfully.");
    }

    private void employeeDetailsWithDepartment() {

        System.out.println();
        System.out.println("EMPLOYEE DETAILS WITH DEPARTMENT");

        employeeService
                .details()
                .forEach(System.out::println);
    }

    private void departmentWiseEmployeeCount() {

        System.out.println();
        System.out.println("DEPARTMENT-WISE EMPLOYEE COUNT");

        employeeService
                .counts()
                .forEach((department, count) ->
                        System.out.println(
                                department + " -> " + count));
    }

    private void executeStoredProcedure() {

        System.out.println();
        System.out.println("1. Get Employees By Department");
        System.out.println("2. Increase Department Salary");

        int choice =
                readInt("Select Option : ");

        switch (choice) {

            case 1:

                int departmentId =
                        readInt("Department ID : ");

                employeeService
                        .procedure1(departmentId)
                        .forEach(System.out::println);

                break;

            case 2:

                int deptId =
                        readInt("Department ID : ");

                double percentage =
                        readDouble("Increase Percentage : ");

                employeeService
                        .procedure2(deptId, percentage);

                System.out.println(
                        "Stored Procedure Executed Successfully.");

                break;

            default:
                System.out.println("Invalid Option.");
        }
    }

    private void transferEmployee() {

        System.out.println();
        System.out.println("TRANSFER EMPLOYEE");

        int employeeId =
                readInt("Employee ID : ");

        int departmentId =
                readInt("New Department ID : ");

        employeeService.transfer(
                employeeId,
                departmentId
        );

        System.out.println(
                "Employee Transfer Completed Successfully.");
    }

    private void batchInsertEmployees() {

        System.out.println();
        System.out.println("BATCH INSERT");

        int count =
                readInt("Number Of Employees : ");

        List<Employee> employeeList =
                new ArrayList<>();

        for (int i = 1; i <= count; i++) {

            System.out.println();
            System.out.println("Employee " + i);

            employeeList.add(
                    readEmployeeData(0)
            );
        }

        int[] results =
                employeeService.batch(employeeList);

        System.out.println(
                "Batch Insert Successful.");

        System.out.println(
                "Rows Inserted : " +
                        Arrays.stream(results).sum());
    }

    private Employee readEmployeeData(int employeeId) {

        System.out.print("Employee Name : ");
        String name = scanner.nextLine();

        System.out.print("Email : ");
        String email = scanner.nextLine();

        double salary =
                readDouble("Salary : ");

        int departmentId =
                readInt("Department ID : ");

        return new Employee(
                employeeId,
                name,
                email,
                salary,
                departmentId
        );
    }

    private int readInt(String message) {

        while (true) {

            try {

                System.out.print(message);

                return Integer.parseInt(
                        scanner.nextLine().trim());

            } catch (NumberFormatException exception) {

                System.out.println(
                        "Please enter a valid integer.");
            }
        }
    }

    private double readDouble(String message) {

        while (true) {

            try {

                System.out.print(message);

                return Double.parseDouble(
                        scanner.nextLine().trim());

            } catch (NumberFormatException exception) {

                System.out.println(
                        "Please enter a valid number.");
            }
        }
    }
}