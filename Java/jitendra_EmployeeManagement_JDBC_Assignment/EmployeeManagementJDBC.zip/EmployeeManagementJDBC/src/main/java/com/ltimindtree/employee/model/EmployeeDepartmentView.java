package com.ltimindtree.employee.model;

public record EmployeeDepartmentView(int employeeId, String employeeName, String email, double salary,
                                     String departmentName) {
}