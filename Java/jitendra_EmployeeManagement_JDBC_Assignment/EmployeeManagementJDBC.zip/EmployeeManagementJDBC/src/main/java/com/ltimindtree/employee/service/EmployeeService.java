package com.ltimindtree.employee.service;

import com.ltimindtree.employee.dao.EmployeeDao;
import com.ltimindtree.employee.exception.*;
import com.ltimindtree.employee.model.*;

import java.sql.*;
import java.util.*;

public class EmployeeService {
    private final EmployeeDao dao;

    public EmployeeService(EmployeeDao dao) {
        this.dao = dao;
    }

    private void validate(Employee e) {
        if (e.getEmployeeName() == null || e.getEmployeeName().isBlank())
            throw new IllegalArgumentException("Name is required");
        if (e.getEmail() == null || !e.getEmail().contains("@"))
            throw new IllegalArgumentException("Valid email is required");
        if (e.getSalary() < 0) throw new IllegalArgumentException("Salary cannot be negative");
        if (e.getDepartmentId() <= 0) throw new IllegalArgumentException("Department ID must be positive");
    }

    public int add(Employee e) {
        validate(e);
        try {
            return dao.add(e);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public List<Employee> all() {
        try {
            return dao.findAll();
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public Employee one(int id) {
        try {
            return dao.findById(id).orElseThrow(() -> new RecordNotFoundException("Employee not found: " + id));
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public void update(Employee e) {
        validate(e);
        try {
            if (!dao.update(e)) throw new RecordNotFoundException("Employee not found: " + e.getEmployeeId());
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public void delete(int id) {
        try {
            if (!dao.delete(id)) throw new RecordNotFoundException("Employee not found: " + id);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public List<Employee> byDepartment(int d) {
        try {
            return dao.findByDepartment(d);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public List<EmployeeDepartmentView> details() {
        try {
            return dao.findEmployeeDepartmentDetails();
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public Map<String, Integer> counts() {
        try {
            return dao.countByDepartment();
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public List<Employee> procedure1(int d) {
        try {
            return dao.callEmployeesByDepartment(d);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public void procedure2(int d, double p) {
        if (p <= 0) throw new IllegalArgumentException("Percentage must be positive");
        try {
            dao.callIncreaseSalary(d, p);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public void transfer(int e, int d) {
        try {
            dao.transferEmployee(e, d);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    public int[] batch(List<Employee> e) {
        e.forEach(this::validate);
        try {
            return dao.batchInsert(e);
        } catch (SQLException x) {
            throw db(x);
        }
    }

    private DatabaseOperationException db(SQLException x) {
        String m = switch (x.getSQLState() == null ? "" : x.getSQLState()) {
            case "23000" -> "Constraint violation: duplicate value or invalid foreign key.";
            case "28000" -> "Invalid database credentials.";
            case "42000" -> "SQL syntax or database object error.";
            case "08S01", "08001", "08003", "08004", "08006" -> "Database is unavailable.";
            default -> "Database operation failed: " + x.getMessage();
        };
        return new DatabaseOperationException(m, x);
    }
}