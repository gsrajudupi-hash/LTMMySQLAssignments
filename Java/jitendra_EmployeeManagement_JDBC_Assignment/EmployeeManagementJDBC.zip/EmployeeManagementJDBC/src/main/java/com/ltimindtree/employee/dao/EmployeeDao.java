package com.ltimindtree.employee.dao;

import com.ltimindtree.employee.model.*;

import java.sql.SQLException;
import java.util.*;

public interface EmployeeDao {
    int add(Employee e) throws SQLException;

    List<Employee> findAll() throws SQLException;

    Optional<Employee> findById(int id) throws SQLException;

    boolean update(Employee e) throws SQLException;

    boolean delete(int id) throws SQLException;

    List<Employee> findByDepartment(int departmentId) throws SQLException;

    List<EmployeeDepartmentView> findEmployeeDepartmentDetails() throws SQLException;

    Map<String, Integer> countByDepartment() throws SQLException;

    List<Employee> callEmployeesByDepartment(int departmentId) throws SQLException;

    void callIncreaseSalary(int departmentId, double percentage) throws SQLException;

    void transferEmployee(int employeeId, int newDepartmentId) throws SQLException;

    int[] batchInsert(List<Employee> employees) throws SQLException;
}