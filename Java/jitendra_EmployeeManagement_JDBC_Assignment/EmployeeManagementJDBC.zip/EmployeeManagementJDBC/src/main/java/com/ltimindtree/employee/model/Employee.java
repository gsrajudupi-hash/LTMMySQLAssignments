package com.ltimindtree.employee.model;

public class Employee {
    private int employeeId;
    private String employeeName;
    private String email;
    private double salary;
    private int departmentId;

    public Employee() {
    }

    public Employee(int employeeId, String employeeName, String email, double salary, int departmentId) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.email = email;
        this.salary = salary;
        this.departmentId = departmentId;
    }

    public Employee(String employeeName, String email, double salary, int departmentId) {
        this(0, employeeName, email, salary, departmentId);
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int v) {
        employeeId = v;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String v) {
        employeeName = v;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String v) {
        email = v;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double v) {
        salary = v;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int v) {
        departmentId = v;
    }

    @Override
    public String toString() {
        return String.format("Employee{id=%d, name='%s', email='%s', salary=%.2f, departmentId=%d}", employeeId, employeeName, email, salary, departmentId);
    }
}